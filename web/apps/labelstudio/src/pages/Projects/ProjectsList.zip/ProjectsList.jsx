import chr from "chroma-js";
import { format } from "date-fns";
import { useMemo, useState, useEffect } from "react";
import { NavLink } from "react-router-dom";
import { useSwipeable } from "react-swipeable";
import { IconCheck, IconEllipsis, IconMinus, IconSparks, IconSearch } from "@humansignal/icons";
import { Userpic } from "@humansignal/ui";
import { Button, Dropdown, Menu } from "../../components";
import { Block, Elem } from "../../utils/bem";
import { absoluteURL } from "../../utils/helpers";

const DEFAULT_CARD_COLORS = ["#FFFFFF", "#FDFDFC"];
const ROWS_PER_PAGE = 15; // number of rows per page

export const ProjectsList = ({ projects, pageSize }) => {
  const [currentPage, setCurrentPage] = useState(0);
  const [searchQuery, setSearchQuery] = useState("");
  const [showSearch, setShowSearch] = useState(false);
  const [loading, setLoading] = useState(true); // 👈 loader state

  useEffect(() => {
    // simulate loader, jab projects aa jaye to hide loader
    const timer = setTimeout(() => setLoading(false), 800);
    return () => clearTimeout(timer);
  }, [projects]);

  const totalPages = Math.ceil(projects.length / ROWS_PER_PAGE);

  const handlers = useSwipeable({
    onSwipedLeft: () => setCurrentPage((prev) => Math.min(prev + 1, totalPages - 1)),
    onSwipedRight: () => setCurrentPage((prev) => Math.max(prev - 1, 0)),
    trackMouse: true,
  });

  const filteredProjects = projects.filter((project) =>
    project.title?.toLowerCase().includes(searchQuery.toLowerCase()) ||
    project.description?.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const startIndex = currentPage * ROWS_PER_PAGE;
  const endIndex = startIndex + ROWS_PER_PAGE;

  const visibleProjects =
    filteredProjects.length <= ROWS_PER_PAGE
      ? filteredProjects
      : filteredProjects.slice(startIndex, endIndex);

  return (
    <div>
      {/* Search Section */}
      <div style={{ display: "flex", justifyContent: "center", padding: "5px 20px" }}>
        {showSearch ? (
          <input
            type="text"
            autoFocus
            placeholder="Search projects..."
            value={searchQuery}
            onChange={(e) => {
              setSearchQuery(e.target.value);
              setCurrentPage(0);
            }}
            onBlur={() => {
              if (searchQuery === "") setShowSearch(false);
            }}
            style={{
              width: "100%",
              maxWidth: "400px",
              padding: "8px 12px",
              borderRadius: "8px",
              border: "1px solid #e5e7eb",   // 👈 lighter border (#e5e7eb is lighter grey)
              fontSize: "14px",
              transition: "all 0.3s ease-in-out",
            }}

          />
        ) : (
          <button
            onClick={() => setShowSearch(true)}
            style={{
              background: "transparent",
              border: "none",
              cursor: "pointer",
            }}
          >
            <IconSearch style={{ width: 22, height: 22, color: "#374151" }} />
          </button>
        )}
      </div>

      {/* Loader Section */}
      {loading ? (
        <div style={{ textAlign: "center", padding: "50px", color: "#6b7280" }}>
          <div className="spinner" style={{
            width: "40px",
            height: "40px",
            border: "4px solid #e5e7eb",
            borderTop: "4px solid #374151",
            borderRadius: "50%",
            margin: "0 auto",
            animation: "spin 1s linear infinite"
          }} />
          <p>Loading projects...</p>
          <style>
            {`
              @keyframes spin {
                0% { transform: rotate(0deg); }
                100% { transform: rotate(360deg); }
              }
            `}
          </style>
        </div>
      ) : (
        <div {...(filteredProjects.length > ROWS_PER_PAGE ? handlers : {})} style={{ overflow: "hidden" }}>
          <Elem
            name="list"
            style={{
              display: "grid",
              gridTemplateColumns: "repeat(auto-fill, minmax(320px, 1fr))",
              gap: "20px",
              padding: "5px",
              transition: "transform 0.3s ease",
            }}
          >
            {visibleProjects.length > 0 ? (
              visibleProjects.map((project) => (
                <ProjectCard key={project.id} project={project} />
              ))
            ) : (
              <p style={{ gridColumn: "1 / -1", textAlign: "center", color: "#6b7280" }}>
                No projects found.
              </p>
            )}
          </Elem>

          {filteredProjects.length > ROWS_PER_PAGE && (
            <Elem
              name="pages"
              style={{ marginTop: "20px", display: "flex", justifyContent: "center", gap: "5px" }}
            >
              {Array.from({ length: Math.ceil(filteredProjects.length / ROWS_PER_PAGE) }).map((_, index) => (
                <div
                  key={index}
                  style={{
                    width: 8,
                    height: 8,
                    borderRadius: "50%",
                    background: index === currentPage ? "#374151" : "#d1d5db",
                    cursor: "pointer",
                  }}
                  onClick={() => setCurrentPage(index)}
                />
              ))}
            </Elem>
          )}
        </div>
      )}
    </div>
  );
};

export const EmptyProjectsList = ({ openModal }) => {
  return (
    <Block name="empty-projects-page">
      <Elem name="heidi" tag="img" src={absoluteURL("/static/images/opossum_looking.png")} />
      <Elem name="header" tag="h1">
        Heidi doesn’t see any projects here!
      </Elem>
      <p>Create one and start labeling your data.</p>
      <Elem name="action" tag={Button} onClick={openModal} look="primary">
        Create Project
      </Elem>
    </Block>
  );
};

const ProjectCard = ({ project }) => {
  const color = useMemo(() => {
    return DEFAULT_CARD_COLORS.includes(project.color) ? null : project.color;
  }, [project]);

  const projectColors = useMemo(() => {
    const textColor =
      color && chr(color).luminance() > 0.3
        ? "var(--color-neutral-inverted-content)"
        : "var(--color-neutral-inverted-content)";
    return color
      ? {
        "--header-color": color,
        "--background-color": chr(color).alpha(0.08).css(),
        "--text-color": textColor,
        "--border-color": chr(color).alpha(0.3).css(),
      }
      : {};
  }, [color]);

  return (
    <Elem
      tag={NavLink}
      name="link"
      to={`/projects/${project.id}/data`}
      data-external
      style={{ textDecoration: "none" }}
    >
      <Block
        name="project-card"
        mod={{ colored: !!color }}
        style={{
          ...projectColors,
          background: "#fff",
          border: "1px solid var(--border-color, #e5e7eb)",
          borderRadius: "16px",
          boxShadow: "0 2px 6px rgba(0,0,0,0.05)",
          display: "flex",
          flexDirection: "column",
          overflow: "hidden",
        }}
      >
        {/* Header */}
        <Elem
          name="header"
          style={{
            padding: "6px 10px",
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
            background: "rgb(231, 237, 255)",   // 👈 pure blue background for full header
            color: "#ffffff",        // 👈 white text/icons
          }}
        >
          <Elem name="title" style={{ display: "flex", alignItems: "center", gap: "6px" }}>
            <Elem
              name="title-text"
              style={{
                color: "black",
                padding: "4px 12px",
                borderRadius: "6px",
                background: "transparent",

                fontSize: "16px",
                fontWeight: "900",            // super bold
                fontFamily: "'Times New Roman', serif", // serif look
                letterSpacing: "1px",         // space between letters
                textTransform: "uppercase",   // all caps


                // 👈 stylish clean font
                // 👈 हर शब्द का पहला अक्षर capital
              }}
            >
              {project.title ?? "New project"}
            </Elem>
          </Elem>
          <Elem
            name="menu"
            onClick={(e) => {
              e.stopPropagation();
              e.preventDefault();
            }}
          >
            <Dropdown.Trigger
              content={
                <Menu contextual>
                  <Menu.Item href={`/projects/${project.id}/settings`}>Settings</Menu.Item>
                  <Menu.Item href={`/projects/${project.id}/data?labeling=1`}>Label</Menu.Item>
                </Menu>
              }
            >
              <Button
                size="small"
                type="text"
                icon={<IconEllipsis style={{ color: "black" }} />}
              />

            </Dropdown.Trigger>
          </Elem>
        </Elem>

        {/* Stats */}
        <Elem
          name="summary"
          style={{
            padding: "10px",
            background: "#f9fafb",
            boxShadow: "inset 0 1px 3px rgba(0,0,0,0.05)",
          }}
        >
          <Elem name="annotation" style={{ fontSize: "13px", color: "#374151" }}>
            <Elem name="total" style={{ fontWeight: "500" }}>
              {project.finished_task_number} / {project.task_number}
            </Elem>
            <Elem
              name="detail"
              style={{
                display: "flex",
                marginTop: "8px",
                fontSize: "12px",
              }}
            >
              <Elem name="detail-item" mod={{ type: "completed" }} style={{ color: "green" }}>
                <IconCheck style={{ width: 14, height: 14 }} /> {project.total_annotations_number}
              </Elem>
              <Elem name="detail-item" mod={{ type: "rejected" }} style={{ color: "red" }}>
                <IconMinus style={{ width: 14, height: 14 }} /> {project.skipped_annotations_number}
              </Elem>
              <Elem name="detail-item" mod={{ type: "predictions" }} style={{ color: "blue" }}>
                <IconSparks style={{ width: 14, height: 14 }} /> {project.total_predictions_number}
              </Elem>
            </Elem>
          </Elem>
        </Elem>

        {/* Description */}
        <Elem
          name="description"
          style={{
            padding: "12px",
            fontSize: "13px",
            color: "#374151",
            background: "#ffffff",
            borderRadius: "10px",
            margin: "0 10px 10px 10px",
            border: "2px solid #f3f4f6",
            minHeight: "40px",
            fontFamily: "'Times New Roman', serif", // serif look
            letterSpacing: "1px",         // space between letters
            textTransform: "uppercase",
          }}
        >
          {project.description || "No description available."}
        </Elem>

        {/* Footer */}
        <Elem
          name="info"
          style={{
            padding: "10px 12px",
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
            fontSize: "16px",
            background: "#f9fafb",
            borderTop: "1px dashed #e5e7eb",
            borderRadius: "0 0 12px 12px",
            color: "black",
            fontWeight: "900",            // super bold
            fontFamily: "'Times New Roman', serif", // serif look
            letterSpacing: "1px",         // space between letters
            textTransform: "uppercase",
          }}

        >
          <Elem name="created-date">
            {format(new Date(project.created_at), "dd MMM ’yy, HH:mm")}
          </Elem>
          <Elem name="created-by">
            <Userpic src="#" user={project.created_by} showUsername />
          </Elem>
        </Elem>
      </Block>
    </Elem>
  );
};
